//
//  QualityDetailViewController.h
//  cms
//
//  Created by John Cassidy on 7/22/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SpecialtyMeasure.h"


@interface QualityDetailViewController : UIViewController

@property (nonatomic, strong) SpecialtyMeasure *measure;

@end

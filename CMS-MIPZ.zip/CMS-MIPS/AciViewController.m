//
//  AciViewController.m
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/2/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "AciViewController.h"
#import "QualityTableViewCell.h"

@interface AciViewController ()

@property (nonatomic, strong) NSMutableArray *arrBase;
@property (nonatomic, strong) NSMutableArray *arrPerformanceObjectives;
@property (nonatomic, strong) NSMutableArray *arrBonus;

@property (nonatomic, strong) NSMutableArray *arrRequired;
@property (nonatomic, strong) NSMutableArray *arrMustFillOut;
@property (nonatomic, strong) NSMutableArray *arrEarnPoints;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation AciViewController

//https://www.cms.gov/Medicare/Quality-Initiatives-Patient-Assessment-Instruments/Value-Based-Programs/MACRA-MIPS-and-APMs/Advancing-Care-Information-Fact-Sheet.pdf

//Blog: ACI:  https://blog.cms.gov/2016/04/27/moving-toward-improved-care-through-information/


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Advancing Care Information";
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 90.0;
   
    @"Must Do - or no points earned";
    @"Must Enter Yes or No - or no points earned";
    @"Earn points for these";
    
    
    self.arrBase = [[NSMutableArray alloc] initWithObjects:@"Protect Patient Health Information", @"Electronic Prescribing", @"Patient Electronic Access", @"Coordination of Care through Patient Engagement", @"Health Information Exchange", @"Public Health and Clinical Data Registry Reporting", nil];
    
    NSString *note = @"Because of the importance of protecting patient privacy and security, physicians and other clinicians must be able to report “yes” to the Protect Patient Health Information objective to receive any score in the Advance Care Information performance category.";
    
    
    self.arrPerformanceObjectives = [[NSMutableArray alloc] initWithObjects:@"Patient Electronic Access", @"Coordination of Care through Patient Engagement", @"Health Information Exchange", nil];
    
    self.arrBonus = [[NSMutableArray alloc] initWithObjects:@"Public Health Registry", nil];
    
    UIView *viewHeader = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 60)];
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(8,4, viewHeader.bounds.size.width-16, 44)];
    lbl.numberOfLines = 0;
    lbl.lineBreakMode = NSLineBreakByWordWrapping;
    lbl.text = @"Confirm that you do the following in order to earn points. ";
    [viewHeader addSubview:lbl];
    
    self.tableView.tableHeaderView = viewHeader;
    
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section  {

      
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 60)];
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(16,8,self.view.bounds.size.width-32,48)];
    if (section == 0)  {
        lbl.text = @"Required - Must do to earn any points";
        lbl.textColor = [UIColor redColor];
    }
    else if (section == 1)  {
        lbl.text = @"Required - Enter yes or no to earn the 50 points Base Score";
        lbl.textColor = [UIColor redColor];
   }
    else if (section == 2)  {
        lbl.text = @"Enter yes to at least 5 to get the maximum 100 points in the Performance score";
        lbl.textColor = [UIColor darkTextColor];
   }
    else if (section == 3)  {
        lbl.text = @"Bonus of 1 point";
        lbl.textColor = [UIColor darkTextColor];
   }
    lbl.numberOfLines = 0;
    lbl.lineBreakMode = NSLineBreakByWordWrapping;
    
    [view addSubview:lbl];
    
    view.backgroundColor = [UIColor colorWithRed:241.0/255.0f green:241.0/255.0f blue:241.0/255.0f alpha:1.0];
    return view;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellId = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellId];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
    }
    
    if (indexPath.section == 0)  {
        if (indexPath.row == 0)
            cell.textLabel.text = @"Protect Patient Health Information. (Required)";
        else if (indexPath.row == 1)
            cell.textLabel.text = @"Public Health and Clinical Data Registry Reporting. (Required)";
    }
    else if (indexPath.section == 1)  {
        if (indexPath.row == 0)
            cell.textLabel.text = @"Electronic Prescribing";
    }
    else if (indexPath.section == 2)  {
        if (indexPath.row == 0)
            cell.textLabel.text = @"Patient Electronic Access - Patent Access";
        else if (indexPath.row == 1)
            cell.textLabel.text = @"Patient Electronic Access - Patent-Specific Education";

        
        else if (indexPath.row == 2)
            cell.textLabel.text = @"Coordination of Care Through Patient Engagement - View Download and Transmit (VDT)";
        else if (indexPath.row == 3)
            cell.textLabel.text = @"Coordination of Care Through Patient Engagement - Secure Messaging";
        else if (indexPath.row == 4)
            cell.textLabel.text = @"Coordination of Care Through Patient Engagement - Patient-Generated Health Data";
        
        
        
        else if (indexPath.row == 5)
            cell.textLabel.text = @"Health Information Exchange - Exchange information with other physicians or clinicians";
        else if (indexPath.row == 6)
            cell.textLabel.text = @"Health Information Exchange - Exchange information with patients";
        else if (indexPath.row == 7)
            cell.textLabel.text = @"Health Information Exchange - Clinical Informaton Reconciliation";
        
        
        
    }
    else if (indexPath.section == 3)  {
        if (indexPath.row == 0)  {
            cell.textLabel.text = @"Public Health Registry";
        }
    }
    
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;

    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    

    if (indexPath.section == 0)  {
        
    }
    
 //   [self performSegueWithIdentifier:@"QualityDetailViewController" sender:self];
    
 //   self.navigationItem.hidesBackButton = NO;
    
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
      return 60;

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0)
        return 2;
    else if (section == 1)
        return 1;
    else if (section == 2)
        return 8;
    else if (section == 3)
        return 1;

    return 1;
    
}













- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

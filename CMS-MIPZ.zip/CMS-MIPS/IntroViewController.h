//
//  IntroViewController.h
//  MIPS
//
//  Created by Claudia Cassidy on 9/3/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IntroViewController : UIViewController 

@end


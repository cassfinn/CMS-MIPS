//
//  MenuViewController.h
//  MIPS
//
//  Created by Claudia Cassidy on 9/5/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController <UIGestureRecognizerDelegate>

@end

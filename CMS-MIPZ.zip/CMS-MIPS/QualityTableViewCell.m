//
//  QualityTableViewCell.m
//  cms
//
//  Created by John Cassidy on 7/16/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "QualityTableViewCell.h"

@implementation QualityTableViewCell



@end

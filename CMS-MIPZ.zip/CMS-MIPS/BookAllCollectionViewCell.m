//
//  BookAllCollectionViewCell.m
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 9/24/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "BookAllCollectionViewCell.h"

@implementation BookAllCollectionViewCell

@end

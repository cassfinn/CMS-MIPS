//
//  AboutWebViewController.h
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/15/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Presentation.h"

@interface AboutWebViewController : UIViewController

@property (nonatomic, strong) Presentation *presentation;

@end

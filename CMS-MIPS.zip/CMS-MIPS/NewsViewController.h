//
//  NewsViewController.h
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/15/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController

@end

//
//  SpecialtyMeasure.m
//  cms
//
//  Created by John Cassidy on 7/17/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "SpecialtyMeasure.h"

@implementation SpecialtyMeasure



@end

//
//  BookAllCollectionViewCell.h
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 9/24/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookAllCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end

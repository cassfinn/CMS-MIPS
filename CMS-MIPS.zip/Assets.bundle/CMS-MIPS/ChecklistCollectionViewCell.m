//
//  ChecklistCollectionViewCell.m
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/9/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "ChecklistCollectionViewCell.h"

@implementation ChecklistCollectionViewCell

@end

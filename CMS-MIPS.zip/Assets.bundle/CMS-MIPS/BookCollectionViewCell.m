//
//  BookCollectionViewCell.m
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 9/23/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "BookCollectionViewCell.h"

@implementation BookCollectionViewCell

@end

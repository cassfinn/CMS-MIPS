//
//  YearCollectionViewCell.m
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/8/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import "YearCollectionViewCell.h"

@implementation YearCollectionViewCell

@end

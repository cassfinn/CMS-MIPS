//
//  BookCollectionViewCell.h
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 9/23/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end

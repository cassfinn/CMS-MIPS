//
//  AciCategory.h
//  CMS-MIPS
//
//  Created by Claudia Cassidy on 10/6/16.
//  Copyright © 2016 Claudia Cassidy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AciCategory : NSObject


@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSMutableArray *arrMeasure;




@end
